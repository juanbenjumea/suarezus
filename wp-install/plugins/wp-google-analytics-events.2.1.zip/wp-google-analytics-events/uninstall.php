<?php
if( !defined( 'WP_UNINSTALL_PLUGIN' ) )
    exit ();

//delete_option( 'ga_scroll_events_install' );
?>
