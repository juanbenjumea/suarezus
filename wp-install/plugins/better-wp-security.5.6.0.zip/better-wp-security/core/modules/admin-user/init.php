<?php

ITSEC_Modules::register_module( 'admin-user', dirname( __FILE__ ), 'always-active' );
