<?php

ITSEC_Modules::register_module( 'away-mode', dirname( __FILE__ ) );
