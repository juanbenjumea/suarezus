<?php

ITSEC_Modules::register_module( 'file-permissions', dirname( __FILE__ ), 'always-active' );
