<?php

ITSEC_Modules::register_module( 'content-directory', dirname( __FILE__ ), 'always-active' );
