<?php

ITSEC_Modules::register_module( 'pro-module-upsells', dirname( __FILE__ ), 'always-active' );
