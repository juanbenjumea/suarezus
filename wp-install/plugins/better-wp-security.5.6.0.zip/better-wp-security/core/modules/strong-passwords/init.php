<?php

ITSEC_Modules::register_module( 'strong-passwords', dirname( __FILE__ ), 'default-active' );
