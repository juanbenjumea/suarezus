<?php


# functions, get hurl info
function fastvelocity_min_get_hurl($src, $wp_domain, $protocol, $wp_home) {
$hurl = trim($src); if(empty($hurl)) { return $hurl; } # preserve empty source handles

# apply some filters
if (substr($hurl, 0, 2) === "//") { $hurl = $protocol.ltrim($hurl, "/"); }  # protocol only
if (substr($hurl, 0, 4) !== "http" && stripos($hurl, $wp_domain) !== false) { $hurl = $wp_home.'/'.ltrim($hurl, "/"); } # protocol + home
if (substr($hurl, 0, 12) === "/wp-includes" || substr($hurl, 0, 9) === "/wp-admin" || substr($hurl, 0, 11) === "/wp-content") { $hurl = $wp_home.'/'.ltrim($hurl, "/"); } # protocol + home for relative paths
return $hurl;	
}


# functions, minify html
function fastvelocity_min_minify_html($html) {
$replace = array(
# remove tabs before and after HTML tags
'/\>[^\S ]+/s' => '>',
'/[^\S ]+\</s' => '<',
# shorten multiple whitespace sequences; keep new-line characters because they matter in JS!!!
'/([\t ])+/s' => ' ',
//remove leading and trailing spaces
'/^([\t ])+/m' => '',
'/([\t ])+$/m' => '',
# remove JS line comments (simple only); do NOT remove lines containing URL (e.g. 'src="http://server.com/"')!!!
'~//[a-zA-Z0-9 ]+$~m' => '',
# remove empty lines (sequence of line-end and white-space characters)
'/[\r\n]+([\t ]?[\r\n]+)+/s' => "\n",
# remove empty lines (between HTML tags); cannot remove just any line-end characters because in inline JS they can matter!
'/\>[\r\n\t ]+\</s' => '><',
# remove "empty" lines containing only JS's block end character; join with next line (e.g. "}\n}\n</script>" --> "}}</script>"
'/}[\r\n\t ]+/s' => '}',
'/}[\r\n\t ]+,[\r\n\t ]+/s' => '},',
# remove new-line after JS's function or condition start; join with next line
'/\)[\r\n\t ]?{[\r\n\t ]+/s' => '){',
'/,[\r\n\t ]?{[\r\n\t ]+/s' => ',{',
# remove new-line after JS's line end (only most obvious and safe cases)
'/\),[\r\n\t ]+/s' => '),',
# remove quotes from HTML attributes that does not contain spaces; keep quotes around URLs!
'~([\r\n\t ])?([a-zA-Z0-9]+)="([a-zA-Z0-9_/\\-]+)"([\r\n\t ])?~s' => '$1$2=$3$4', //$1 and $4 insert first white-space character found before/after attribute
);
return preg_replace(array_keys($replace), array_values($replace), $html);
}


# case-insensitive in_array() wrapper
function fastvelocity_min_in_arrayi($needle, $haystack){
	return in_array(strtolower($needle), array_map('strtolower', $haystack));
}



# process minification of javascript files
function fastvelocity_min_minify_js_process($jsfile) {
	
# default settings
global $use_google_closure, $tmpdir;

# default cache path location
$jstmp = $tmpdir.'/'.hash('adler32', $jsfile).'-'.basename($jsfile);
$jstmplog = $jstmp.'.log';

# return from cache if it's still valid
if(file_exists($jstmp) && file_exists($jstmplog) && filesize($jstmp) > 0 && filemtime($jstmp) >= filemtime($jsfile)) {
	$output = file_get_contents($jstmp); # use cache
	return array('js'=>$output, 'log'=>file_get_contents($jstmplog).' [cache]');
	exit();
}

# check for exec + a supported java version
if(function_exists('exec') && exec('command -v java >/dev/null && echo "yes" || echo "no"') == 'yes' && exec('java -version 2>&1', $jav_version) && preg_match("/java\ version\ \"[0-9]+\.([7-9]{1}+|[0-9]{2,}+)\..*/", $jav_version[0])) {
	
	# define jar paths
	$yui = WP_PLUGIN_DIR.'/fast-velocity-minify/libs/jar/yuicompressor-2.4.8.jar';
	$gog = WP_PLUGIN_DIR.'/fast-velocity-minify/libs/jar/google-closure.jar';
	
	# choose between YUI or Google Closure, YUI by default (faster)
	if($use_google_closure) {
		$cmd = 'java -jar '.$gog.' --warning_level QUIET --js '.$jsfile.' --js_output_file '.$jstmp;
		$savelog = 'GOOGLE CLOSURE';
	} else {
		$cmd = 'java -jar '.$yui.' --preserve-semi '.$jsfile.' -o '.$jstmp;
		$savelog = 'YUI COMPRESSOR';
	}
	
	# save log
	file_put_contents($jstmplog, $savelog, LOCK_EX);
	
	# run local compiler
	exec($cmd . ' 2>&1', $output);
	if(count($output) == 0 && file_exists($jstmp)) {
		$output = file_get_contents($jstmp);
		return array('js'=>$output, 'log'=>$savelog);
		exit();
	}		
}
	
# this is our last resort fallback
$savelog = 'MERGED [php exec or java unavailable]';
file_put_contents($jstmplog, $savelog, LOCK_EX);
return array('js'=>file_get_contents($jsfile, LOCK_EX), 'log'=>$savelog);
exit();

}
	

# minify js on demand (one file at one time, for compatibility)
function fastvelocity_min_minify_js($handle, $url, $path, $nocompress) {
	
# try to get the unminified version if available, for better compatibility	
$xtralog = '';
$ignorehandles = array('jquery-core', 'jquery', 'jquery-migrate');
if (!fastvelocity_min_in_arrayi($handle, $ignorehandles)) {
$use = str_ireplace(array('.min.js', '-min.js'), '.js', $path);
if($use != $path && file_exists($use)) { $path = $use; $xtralog = ' [unminified file used]'; }
if (stripos(basename($url), 'min.js') && empty($xtralog)) { $xtralog = ' [minified file]'; }
} else { $xtralog = ' [minified file]'; }

# basic cleaning and minification
$js = preg_replace("/^\xEF\xBB\xBF/", '', file_get_contents($path)); # remove BOM
$js = trim(join("\n", array_map("trim", explode("\n", preg_replace('/\v+/', "\n", preg_replace('/\h+/', " ", $js)))))); # BASIC MINIFICATION

# jQuery no conflict mode
if (stripos(basename($path), 'jquery.js') !== false) { $js = $js."jQuery.noConflict();"; }

# exclude minification on already minified files + jquery (because minification might break those)
$excl = array('jquery.js', '.min.js', '-min.js'); 
foreach($excl as $e) { if (stripos(basename($path), $e) !== false) { $nocompress = true; break; } }	

# default log
$loginfo = 'MERGED';

# minification (if allowed)
if (!$nocompress) { 
	$newjsarr = fastvelocity_min_minify_js_process($path);
	if (empty($newjsarr['js'])) { 
		$xtralog = ' [empty file]';
	} else {
		$js = $newjsarr['js'];
		$loginfo = $newjsarr['log'];
	}
}

# define log
$log = " - $loginfo".$xtralog." - $handle - $url \n"; 


# fix compatibility when mergin some scripts
if(substr($js, -1) != ';') { $js = $js.";\n"; } $js = $js."\n";

# return html
return array('js'=> $js, 'log' => $log);
}



# minify css string
function fastvelocity_min_minify_css_string($css) {
$css = preg_replace(array('#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')|\/\*(?!\!)(?>.*?\*\/)|^\s*|\s*$#s','#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\'|\/\*(?>.*?\*\/))|\s*+;\s*+(})\s*+|\s*+([*$~^|]?+=|[{};,>~+]|\s*+-(?![0-9\.])|!important\b)\s*+|([[(:])\s++|\s++([])])|\s++(:)\s*+(?!(?>[^{}"\']++|"(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')*+{)|^\s++|\s++\z|(\s)\s+#si','#(?<=[\s:])(0)(cm|em|ex|in|mm|pc|pt|px|vh|vw|%)#si','#:(0\s+0|0\s+0\s+0\s+0)(?=[;\}]|\!important)#i','#(background-position):0(?=[;\}])#si', '#(?<=[\s:,\-])0+\.(\d+)#s', '#(\/\*(?>.*?\*\/))|(?<!content\:)([\'"])([a-z_][a-z0-9\-_]*?)\2(?=[\s\{\}\];,])#si', '#(\/\*(?>.*?\*\/))|(\burl\()([\'"])([^\s]+?)\3(\))#si', '#(?<=[\s:,\-]\#)([a-f0-6]+)\1([a-f0-6]+)\2([a-f0-6]+)\3#i', '#(?<=[\{;])(border|outline):none(?=[;\}\!])#', '#(\/\*(?>.*?\*\/))|(^|[\{\}])(?:[^\s\{\}]+)\{\}#s'), 
array('$1', '$1$2$3$4$5$6$7', '$1', ':0', '$1:0 0', '.$1', '$1$3', '$1$2$4$5', '$1$2$3', '$1:0', '$1$2' ), $css); # minify
$css = preg_replace('!/\*.*?\*/!s','', $css); # no css comments
return $css;	
}




# minify css on demand (one file at one time, for compatibility)
function fastvelocity_min_minify_css($handle, $url, $path, $skip_clean_fonts, $disable_css_minification) {

# default settings
global $tmpdir;
$savelog = 'MERGED';
$xtralog = '';

# must have, or log error
if(!is_file($path)) { return array('css'=> '', 'log' => 'NOT FOUND'); }

# default cache path location
$csstmp = $tmpdir.'/'.hash('adler32', $path).'-'.basename($path);
$csstmplog = $jstmp.'.log';

# return from cache if it's still valid
if(file_exists($csstmp) && file_exists($csstmplog) && filesize($csstmp) > 0 && filemtime($csstmp) >= filemtime($path)) {
	$css = file_get_contents($csstmp, LOCK_EX);
	$log = ' - '.file_get_contents($csstmplog)." [cache] - $handle - $url \n";
	return array('css'=>$css, 'log'=>$log);
	exit();
}



# basic processing with PHP
$css = preg_replace("/^\xEF\xBB\xBF/", '', file_get_contents($path)); # remove BOM
$css = preg_replace("/url\(\s*['\"]?(?!data:)(?!http)(?![\/'\"])(.+?)['\"]?\s*\)/i", "url(".dirname($url)."/$1)", $css); # fix paths

# remove query strings from fonts (for better seo, but add a small cache buster based on most recent updates)
if(!$skip_clean_fonts) { $css = preg_replace('/(.eot|.svg|.woff2|.woff|.ttf)+[?+](.+?)(\)|\'|\")/', "$1"."#".filemtime($path)."$3", $css); }

# minify CSS
if(!$disable_css_minification) {
	$mincss = fastvelocity_min_minify_css_string($css);
	$savelog = 'MINIFIED';
	$css = $mincss;
	if (empty($mincss)) { $xtralog = ' [empty file]'; }
}

# save css +  logs
file_put_contents($csstmp, $css, LOCK_EX);
file_put_contents($csstmplog, $savelog, LOCK_EX);

# generate log
$log = " - $savelog".$xtralog." - $handle - $url \n";

# return html
return array('css'=> $css, 'log' => $log);
}



# functions to minify HTML
function fastvelocity_min_html_compression_finish($html) { return fastvelocity_min_minify_html($html); }
function fastvelocity_min_html_compression_start() { ob_start('fastvelocity_min_html_compression_finish'); }


# remove all cache files
function rrmdir($dir) {
foreach(glob($dir.'/{,.}*', GLOB_BRACE) as $file) { 
	if (basename($file) != '.' && basename($file) != '..') { if (is_dir($file)) { $this->rrmdir($file); } else { @unlink($file); } }
}
rmdir($dir);
}




# Concatenate Google Fonts tags (http://fonts.googleapis.com/css?...)
function fastvelocity_min_concatenate_google_fonts($array) {
global $protocol;

$fonts = array(); 
foreach ($array as $font) {

# skip if fonts are already concatenated in this url (for further development later)
if(stristr($string, '|') !== FALSE) { continue; }

# get fonts name, type and subset, remove wp query strings
$font = explode('family=', htmlspecialchars_decode(rawurldecode(urldecode($font))));
$a = explode('&v', end($font)); $font = trim(current($a));
		
# if no type or subset
if(stristr($font, ':') === FALSE) { 
	$fonts[] = array('name'=>$font, 'type'=>'', 'sub'=>''); 
} else {

	# get type and subset
	$name = stristr($font, ':', true);       # font name, before :
	$ftype = trim(stristr($font, ':'), ':'); # second part of the string, after :

	# get font types and subset
	if(stristr($ftype, '&subset=') === FALSE) { 
		$fonts[] = array('name'=>$name, 'type'=>$ftype, 'sub'=>''); 
	} else { 
		$newftype = stristr($ftype, '&', true);        # font type, before &
		$subset = trim(str_ireplace('&subset=', '', stristr($ftype, '&')));     # second part of the string, after &
		$fonts[] = array('name'=>$name, 'type'=>$newftype, 'sub'=>$subset); 
	}

}
}

# make sure we have unique font names, types and subsets
$ufonts = array(); foreach ($fonts as $f) { $ufonts[$f['name']] = $f['name']; }                              # unique font names
$usubsets = array(); foreach ($fonts as $f) { if(!empty($f['sub'])) { $usubsets[$f['sub']] = $f['sub']; } }  # unique subsets

# prepare
$fonts_and_types = $ufonts;

# get unique types and subsets for each unique font name
foreach ($ufonts as $uf) {
	
	# types
	$utypes = array(); 
	foreach ($fonts as $f) {
		if($f['name'] == $uf && !empty($f['type'])) { $utypes = array_merge($utypes, explode(',', $f['type'])); }
	}
	
	# filter types
	$utypes = array_unique($utypes);
    sort($utypes);
	$ntype = ''; if(count($utypes) > 0) { $ntype = ':'.implode(',', $utypes); } # types to append to the font name
	
	# generate font url queries
	$fonts_and_types[$uf] = str_ireplace(' ', '+', $uf).$ntype.$nsub;
}

# concat fonts, generate unique google fonts url
if(count($fonts_and_types) > 0) {
	$msubsets = ''; if(count($usubsets) > 0) { $msubsets = '&subset='.implode(',', $usubsets); } # merge subsets
	return 'https://fonts.googleapis.com/css?family='.implode('|', $fonts_and_types).$msubsets;
}

return false;
}
