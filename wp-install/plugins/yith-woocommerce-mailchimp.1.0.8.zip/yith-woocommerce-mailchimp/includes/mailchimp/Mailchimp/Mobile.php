<?php

class Mailchimp_Mobile {
    public function __construct(Mailchimp $master) {
        $this->master = $master;
    }

}


